sap.ui.define([
	"logaligroup/invoices2/test/unit/controller/View_ppal.controller"
], function () {
	"use strict";
});
